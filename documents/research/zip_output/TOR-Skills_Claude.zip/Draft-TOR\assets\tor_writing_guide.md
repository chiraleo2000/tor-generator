# TOR Writing Guide - Formal Thai Government Language

## Vocabulary Reference

| Use (ใช้) | Do Not Use (ห้ามใช้) |
|-----------|---------------------|
| ดำเนินการ | ทำ |
| จัดซื้อจัดจ้าง | ซื้อ/จ้าง |
| ผู้ยื่นข้อเสนอ | ผู้ขาย/ร้าน |
| กำหนดส่งมอบ | เดดไลน์ |
| ให้แล้วเสร็จภายใน | ต้องเสร็จใน |
| เป็นจำนวนเงินทั้งสิ้น | รวมเป็นเงิน |
| พัสดุ | ของ/สิ่งของ |
| ผู้รับจ้าง | ผู้รับเหมา |
| คณะกรรมการตรวจรับพัสดุ | กรรมการรับของ |
| มีความประสงค์จะ | ต้องการจะ |
| ตามที่ได้รับอนุมัติ | ตามที่ OK แล้ว |
| จำนวน X รายการ | X อย่าง |

## Sentence Patterns

### Opening paragraph:
```
ด้วย [หน่วยงาน] มีความประสงค์จะ [จัดซื้อ/จัดจ้าง] [ชื่อโครงการ] 
โดยวิธี [วิธีจัดซื้อ] เป็นจำนวนเงินทั้งสิ้น [X] บาท ([ตัวอักษร]) 
รวมภาษีมูลค่าเพิ่มและค่าใช้จ่ายทั้งปวงแล้ว
```

### Timeline:
```
ผู้รับจ้างต้องดำเนินการให้แล้วเสร็จภายในระยะเวลา [X] วัน 
นับถัดจากวันลงนามในสัญญา
```

### Penalty clause:
```
หากผู้รับจ้างไม่สามารถส่งมอบงาน/พัสดุได้ตามกำหนด 
ผู้รับจ้างจะต้องชำระค่าปรับเป็นรายวัน ในอัตราร้อยละ [X] 
ของราคา [สิ่งของที่ยังไม่ได้รับมอบ/ราคางานจ้างทั้งหมด]
```

### Legal reference:
```
ตามพระราชบัญญัติการจัดซื้อจัดจ้างและการบริหารพัสดุภาครัฐ พ.ศ. ๒๕๖๐ 
มาตรา [XX]
```

### Connectors:
- ทั้งนี้ (furthermore/provided that)
- เว้นแต่ (unless/except)
- โดยอนุโลม (mutatis mutandis)
- อนึ่ง (moreover)
- เพื่อให้เป็นไปตาม (in order to comply with)

## Number Formatting
- Thai numerals (๑)(๒)(๓) for legal article references
- Arabic numerals 1. 2. 3. for TOR section headings
- Budget amounts: both numeral and text (e.g., "500,000 บาท (ห้าแสนบาทถ้วน)")

## Document Structure (13 Standard Sections)
1. ความเป็นมา (Background)
2. วัตถุประสงค์ (Objectives)
3. คุณสมบัติผู้ยื่นข้อเสนอ (Bidder Qualifications)
4. ขอบเขตของงาน (Scope of Work)
5. ระยะเวลาดำเนินการ (Timeline)
6. วงเงินงบประมาณ (Budget)
7. สถานที่ส่งมอบ/ดำเนินการ (Delivery/Work Location)
8. การส่งมอบและตรวจรับ (Delivery and Acceptance)
9. การรับประกัน (Warranty)
10. อัตราค่าปรับ (Penalty Rate)
11. หลักประกัน (Guarantee/Bond)
12. เงื่อนไขอื่นๆ (Other Conditions)
13. เกณฑ์การพิจารณาข้อเสนอ (Evaluation Criteria)
